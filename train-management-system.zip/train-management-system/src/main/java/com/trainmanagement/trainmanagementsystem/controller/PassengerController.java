package com.trainmanagement.trainmanagementsystem.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/passenger")
public class PassengerController {

    @GetMapping
    public String passengerDashboard(Model model) {
        // You can enhance this later with personalized details
        return "passenger-dashboard";
    }
}


